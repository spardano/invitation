import React from 'react';
import ReactDOM from 'react-dom';

import '../build/swiper-bundle.css';

import App from './App.jsx';

// eslint-disable-next-line
ReactDOM.render(React.createElement(App), document.getElementById('app'));
